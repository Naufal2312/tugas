import java.util.Scanner;

public class Player{
    String nama;
    int speed;
    int health;
    int skill = 15;
    
    public void run (){
        this.speed = this.speed + 5;
        System.out.println(" masih berlari.... "); //run menambah speed + 5
    }
    
    public void dead (){
        if(this.health <= 0){
            System.out.println(" Mati ");
        }else{
            System.out.println(" Masih bertahan ");
        }
    }
    public void jurus (){
        this.speed = this.speed - 5;
        System.out.println(" Menggunakan skill "); //menggunakan skill mengurangi speed sebanyak 5
        if(this.speed >= 20){ //jika speed lebih atau sama dengan 20 skill kena
            System.out.println(" Skill kena ");
            System.out.println(" Musuh menerima 20 damage ");
        }else{
            System.out.println(" Skill miss ");
        }
    }
    public static void main(String args[]) {
        Scanner scan = new Scanner (System.in);
        Player udin = new Player ();
        udin.nama = "Udin Sedunia";
        udin.speed = 15;
        udin.health = 50;
        Player laper = new Player (); //saya buat tugas ini pas lagi laper pak
        laper.nama = "GiveMeFood571";
        laper.speed = 20;
        laper.health = 40;
        
        udin.run();
        laper.run();
        udin.jurus();
        laper.jurus();
        udin.health = udin.health - 20;
        udin.dead();
        udin.run();
        laper.jurus();
        udin.run();
        laper.run();
        udin.jurus();
        laper.health = laper.health - 20;
        laper.dead();
        laper.run();
        udin.jurus();
        laper.jurus();
        udin.dead();
        udin.health = udin.health - 20;
        udin.jurus();
        laper.run();
        udin.run();
        laper.jurus();
        udin.health = udin.health - 20;
        udin.dead();
        System.out.println(" Player " + laper.nama + " Menang ");
        }
}